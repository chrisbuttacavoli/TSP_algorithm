#define ALPHA 2.0
#define BETA 0.5
#define Q 1
#define RHO 0.6
#define MIN_DIST 1
#define MIN_PHER 0.1
#define NUM_ITER 200
