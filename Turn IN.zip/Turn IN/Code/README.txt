We use the same program for both the time-unlimited part and competition part.
To compile the program on OSU Flip, at the commend line please do the following:

1. make				(this generates a executable named "run")
2. run INSTANCE_NAME.txt	(it takes a .txt as command-line arguments and then generates a .tour as output)